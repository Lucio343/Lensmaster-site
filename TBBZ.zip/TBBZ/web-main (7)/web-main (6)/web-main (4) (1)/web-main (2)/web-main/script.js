document.addEventListener("DOMContentLoaded", () => {
    // Path to the JSON file
    const jsonFilePath = 'data.json';

    // Fetch the JSON file
    fetch('data.json')
        .then(response => response.json())
        .then(data => populateTable(data))
        .catch(error => console.error("Error fetching data:", error));
});

function populateTable(data) {
    const tableHeader = document.getElementById("table-header");
    const tableBody = document.getElementById("table-body");

    // Define the columns for the table, including the new "price" column
    const columns = ["price", "name", "focal_length", "max_aperture", "type", "compatibility", "id"];

    // Create the table header
    columns.forEach(column => {
        const th = document.createElement("th");
        th.textContent = column.replace("_", " ").toUpperCase(); // Format column names
        tableHeader.appendChild(th);
    });

    // Create the table body
    data.forEach(item => {
        const tr = document.createElement("tr");

        columns.forEach(column => {
            const td = document.createElement("td");
            td.textContent = item[column]; // سيتم إضافة قيمة السعر هنا
            tr.appendChild(td);
        });

        tableBody.appendChild(tr);
    });
}
